"use strict";
/**
 * Binance Futures API Endpoints
 *
 * All REST API endpoints for Binance Futures
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.endpoints = void 0;
exports.endpoints = {
    // Public endpoints
    TIME: '/fapi/v1/time',
    KLINE: '/fapi/v1/klines',
    PRICE: '/fapi/v1/ticker/price',
    BOOK_TICKER: '/fapi/v1/ticker/bookTicker',
    PREMIUM_INDEX: '/fapi/v1/premiumIndex',
    EXCHANGE_INFO: '/fapi/v1/exchangeInfo',
    // Account endpoints (SIGNED)
    ACCOUNT: '/fapi/v3/account',
    BALANCE: '/fapi/v3/balance',
    POSITION_RISK: '/fapi/v3/positionRisk',
    // Trading endpoints (SIGNED)
    ORDER: '/fapi/v1/order',
    ORDER_TEST: '/fapi/v1/order/test',
    CANCEL_ORDER: '/fapi/v1/order',
    CANCEL_ALL_ORDERS: '/fapi/v1/allOpenOrders',
    OPEN_ORDERS: '/fapi/v1/openOrders',
    ALL_ORDERS: '/fapi/v1/allOrders',
    USER_TRADES: '/fapi/v1/userTrades',
    INCOME: '/fapi/v1/income',
    OPEN_ALGO_ORDERS: '/fapi/v1/openAlgoOrders',
    // Position management (SIGNED)
    LEVERAGE: '/fapi/v1/leverage',
    MARGIN_TYPE: '/fapi/v1/marginType',
    POSITION_MODE: '/fapi/v1/positionSide/dual',
    POSITION_MARGIN: '/fapi/v1/positionMargin',
    // Conditional orders use the Algo Order API endpoints (Binance API change)
    ALGO_ORDER: '/fapi/v1/algoOrder',
    CANCEL_ALGO_ORDER: '/fapi/v1/algoOrder',
    CANCEL_ALL_ALGO_ORDERS: '/fapi/v1/allOpenOrders',
    STOP_MARKET_ORDER: '/fapi/v1/algoOrder',
    TAKE_PROFIT_MARKET_ORDER: '/fapi/v1/algoOrder',
    // User Data Stream (SIGNED)
    LISTEN_KEY: '/fapi/v1/listenKey',
};
//# sourceMappingURL=endpoints.js.map