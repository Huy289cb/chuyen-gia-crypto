"use strict";
/**
 * Position monitor thresholds — conservative defaults to protect PnL.
 * Exchange SL/TP are preferred when placed on Binance.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.isPositionMonitorReduceEnabled = isPositionMonitorReduceEnabled;
exports.isPositionMonitorExitEnabled = isPositionMonitorExitEnabled;
exports.isUnhedgedEmergencyExitEnabled = isUnhedgedEmergencyExitEnabled;
exports.getMinMinutesBeforeMonitorAction = getMinMinutesBeforeMonitorAction;
exports.getMinPnlPercentForMonitorAction = getMinPnlPercentForMonitorAction;
exports.getPrecisionSkipMs = getPrecisionSkipMs;
exports.deferToExchangeSlTp = deferToExchangeSlTp;
function isPositionMonitorReduceEnabled() {
    return process.env.POSITION_MONITOR_ALLOW_REDUCE === 'true';
}
/** Default false — exchange SL/TP close positions (PnL+ P0). */
function isPositionMonitorExitEnabled() {
    return process.env.POSITION_MONITOR_ALLOW_EXIT === 'true';
}
/**
 * P1.6: Allow emergency market exit when exchange SL missing and price at/near planned SL.
 * Default true — does not enable discretionary exit for hedged positions.
 */
function isUnhedgedEmergencyExitEnabled() {
    return process.env.POSITION_MONITOR_EXIT_ON_UNHEDGED !== 'false';
}
/** Skip monitor actions on young positions (let exchange orders work). */
function getMinMinutesBeforeMonitorAction() {
    const v = parseInt(process.env.POSITION_MONITOR_MIN_MINUTES || '30', 10);
    return Number.isFinite(v) && v >= 0 ? v : 30;
}
/** Do not reduce/exit on noise — require |pnl%| above this (unless SL progress critical). */
function getMinPnlPercentForMonitorAction() {
    const v = parseFloat(process.env.POSITION_MONITOR_MIN_PNL_PCT || '0.5');
    return Number.isFinite(v) && v >= 0 ? v : 0.5;
}
/** Cooldown after failed Binance close/reduce (ms). */
function getPrecisionSkipMs() {
    const mins = parseInt(process.env.POSITION_MONITOR_PRECISION_SKIP_MIN || '30', 10);
    return (Number.isFinite(mins) && mins > 0 ? mins : 30) * 60 * 1000;
}
/** When true, monitor only marks prices — no reduce/exit if Binance SL+TP order ids exist. */
function deferToExchangeSlTp() {
    return process.env.POSITION_MONITOR_DEFER_TO_EXCHANGE_SLTP !== 'false';
}
//# sourceMappingURL=position-monitor-policy.js.map